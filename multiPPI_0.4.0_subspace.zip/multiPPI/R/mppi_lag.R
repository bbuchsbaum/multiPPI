mppi_lagged <- function(Y, X, psych_idx, lags = -2:2, blocklens = NULL,
                        zero_diag = TRUE, scale = c("cov","corr"),
                        backend = c("blas","chunked"), chunk_size = 2048L) {
  scale <- match.arg(scale); backend <- match.arg(backend)
  X <- .mppi_with_intercept(X)
  all_idx <- seq_len(ncol(X)); p_idx <- sort(unique(psych_idx))
  base_idx <- setdiff(all_idx, p_idx)
  R <- .mppi_residualize(Y, X)
  if (scale == "corr") {
    s <- if (requireNamespace("matrixStats", quietly=TRUE)) matrixStats::colSds(R) else apply(R, 2, sd)
    s[s == 0] <- 1; R <- sweep(R, 2, s, "/")
  }
  out <- list()
  for (ii in seq_along(p_idx)) {
    k  <- p_idx[ii]; Q  <- X[, c(base_idx, setdiff(p_idx, k)), drop = FALSE]
    pk0 <- .mppi_residualize_vec(X[, k], Q)
    for (lg in lags) {
      pk <- if (is.null(blocklens)) {
        if (lg == 0) pk0 else {
          z <- rep(0, length(pk0))
          if (lg > 0) { z[(lg+1):length(z)] <- pk0[1:(length(z)-lg)] }
          else        { z[1:(length(z)+lg)] <- pk0[(1-lg):length(pk0)] }
          z
        }
      } else .mppi_shift_by_run(pk0, lg, blocklens)
      denom <- sum(pk^2)
      Dk <- if (denom < .Machine$double.eps) matrix(NA_real_, ncol(Y), ncol(Y))
            else {
              if (backend == "blas") .mppi_wcp(R, pk) / denom else .mppi_wcp_chunked(R, pk, chunk_size) / denom
            }
      if (zero_diag) diag(Dk) <- 0
      out[[paste0(colnames(X)[k], "_lag", lg)]] <- Dk
    }
  }
  out
}

mppi_lag_select <- function(Y, X, psych_idx, lags = -2:2, blocklens = NULL, B = 499L,
                            blksize = 10L, scale = c("cov","corr"),
                            backend = c("blas","chunked"), chunk_size = 2048L) {
  Dlist <- mppi_lagged(Y, X, psych_idx, lags = lags, blocklens = blocklens, scale = scale,
                       backend = backend, chunk_size = chunk_size)
  R <- .mppi_residualize(Y, .mppi_with_intercept(X))
  Xint <- .mppi_with_intercept(X)
  all_idx <- seq_len(ncol(Xint)); p_idx <- sort(unique(psych_idx))
  base_idx <- setdiff(all_idx, p_idx)
  k <- p_idx[1]; Q <- Xint[, c(base_idx, setdiff(p_idx, k)), drop = FALSE]; pk0 <- .mppi_residualize_vec(Xint[,k], Q)
  Tn <- nrow(R); idx <- split(seq_len(Tn), ceiling(seq_len(Tn)/blksize))
  gen_pk <- function(z) { sgn <- sample(c(-1,1), length(idx), TRUE); out <- numeric(Tn); jj <- 1L; for (g in idx) { out[g] <- sgn[jj]*z[g]; jj <- jj + 1L } ; out }
  Qobs <- sapply(Dlist, function(D) sum(D^2, na.rm = TRUE))
  best <- names(Qobs)[which.max(Qobs)]; lag_best <- as.integer(sub(".*_lag","", best))
  pkb <- if (is.null(blocklens)) {
    if (lag_best == 0) pk0 else { z <- rep(0, length(pk0)); 
      if (lag_best > 0) { z[(lag_best+1):length(z)] <- pk0[1:(length(z)-lag_best)] }
      else { z[1:(length(z)+lag_best)] <- pk0[(1-lag_best):length(pk0)] } ; z }
  } else .mppi_shift_by_run(pk0, lag_best, blocklens)
  denom <- sum(pkb^2)
  Dbest <- if (denom < .Machine$double.eps) matrix(NA_real_, ncol(Y), ncol(Y))
           else { if (backend == "blas") .mppi_wcp(R, pkb) / denom else .mppi_wcp_chunked(R, pkb, chunk_size) / denom }
  Qbest <- sum(Dbest^2, na.rm = TRUE); Qnull <- numeric(B)
  for (b in seq_len(B)) { pkperm <- gen_pk(pkb); Db <- .mppi_wcp(R, pkperm) / sum(pkperm^2); Qnull[b] <- sum(Db^2, na.rm = TRUE) }
  pval <- (1 + sum(Qnull >= Qbest)) / (B + 1)
  list(best_lag = lag_best, Q = Qbest, Qnull = Qnull, p = pval, Qobs = Qobs, Dbest = Dbest)
}
