.mppi_residualize <- function(Y, Z) { B <- qr.coef(qr(Z), Y); Y - Z %*% B }
.mppi_residualize_vec <- function(pk, Q) { pk - Q %*% qr.coef(qr(Q), pk) }
.mppi_wcp <- function(R, w) { crossprod(R, w * R) }
.mppi_with_intercept <- function(X) {
  has_int <- any(apply(X, 2, function(z) sd(z) < .Machine$double.eps && abs(mean(z) - 1) < 1e-12)) ||
             ("(Intercept)" %in% colnames(X))
  if (has_int) X else cbind("(Intercept)" = 1, X)
}
mppi_select_psych <- function(X, patterns = NULL, names_or_idx = NULL) {
  if (!is.null(names_or_idx)) {
    if (is.character(names_or_idx)) return(match(names_or_idx, colnames(X)))
    if (is.numeric(names_or_idx))   return(names_or_idx)
  }
  if (is.null(patterns)) stop("Provide names_or_idx or patterns.")
  keep <- unique(unlist(lapply(patterns, function(p) grep(p, colnames(X), perl = TRUE))))
  if (!length(keep)) stop("No design columns matched patterns.")
  keep
}
.mppi_shift_by_run <- function(x, lag, blocklens) {
  if (lag == 0 || length(blocklens) == 0) return(x)
  out <- x; start <- 1L
  for (L in blocklens) {
    rng <- start:(start + L - 1L); seg <- x[rng]
    if (abs(lag) >= L) out[rng] <- 0
    else if (lag > 0)  out[rng] <- c(rep(0, lag), seg[1:(L - lag)])
    else               out[rng] <- c(seg[(1 - lag):L], rep(0, -lag))
    start <- start + L
  }
  out
}
`%||%` <- function(a, b) if (!is.null(a)) a else b
