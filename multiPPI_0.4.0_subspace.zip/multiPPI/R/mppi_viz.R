mppi_modes <- function(Delta, r = 3L) { ev <- eigen((Delta + t(Delta))/2, TRUE); list(values = ev$values[1:r], vectors = ev$vectors[,1:r,drop=FALSE]) }
mppi_degree <- function(Delta, type = c("L1","L2")) { type <- match.arg(type); A <- abs(Delta); if (type == "L1") rowSums(A, na.rm = TRUE) else sqrt(rowSums(A^2, na.rm = TRUE)) }
mppi_project <- function(Delta, W) { stopifnot(all(dim(Delta) == dim(W))); sum(Delta * W, na.rm = TRUE) }
