# Basis objects ------------------------------------------------------------

#' Create/validate an mppi basis
#' @param V numeric matrix V x r whose columns define the subspace (voxels/ROIs by components).
#' @param name character label for the basis (e.g., "groupPCA200", "Schaefer400").
#' @param orthonormalize logical; if TRUE, columns of V are orthonormalized via QR.
#' @return object of class 'mppi_basis' with fields V, r, name
#' @export
as_mppi_basis <- function(V, name = "user", orthonormalize = TRUE) {
  stopifnot(is.matrix(V))
  if (orthonormalize) {
    q <- qr(V)
    V <- qr.Q(q)
    if (ncol(V) > ncol(qr.R(q))) V <- V[, seq_len(ncol(qr.R(q))), drop = FALSE]
  }
  structure(list(V = V, r = ncol(V), name = name), class = "mppi_basis")
}
