#' Construct an mppi_design from fmridesign models
#' @export
as_mppi_design <- function(event, baseline = NULL, confounds = NULL, include_intercept = TRUE) {
  if (!requireNamespace("fmridesign", quietly = TRUE)) {
    stop("fmridesign not available. Install via remotes::install_github('bbuchsbaum/fmridesign').")
  }
  E <- fmridesign::design_matrix(event)
  B <- if (is.null(baseline)) NULL else fmridesign::design_matrix(baseline)
  X <- NULL
  if (!is.null(B)) X <- B
  if (!is.null(confounds)) { stopifnot(nrow(confounds) == nrow(E)); X <- if (is.null(X)) confounds else cbind(X, confounds) }
  X <- if (is.null(X)) E else cbind(X, E)
  if (include_intercept) {
    has_int <- any(apply(X, 2, function(z) sd(z) < .Machine$double.eps && abs(mean(z) - 1) < 1e-12)) ||
               ("(Intercept)" %in% colnames(X))
    if (!has_int) X <- cbind("(Intercept)" = 1, X)
  }
  start <- ncol(X) - ncol(E) + 1L
  pidx <- start:(start + ncol(E) - 1L)
  structure(list(X = X, psych_idx = pidx, names = list(baseline = colnames(B), event = colnames(E))),
            class = "mppi_design")
}

#' Group event (HRF-expanded) columns by condition name
#' @export
mppi_group_hrf_columns <- function(design, event_colnames = NULL) {
  if (inherits(design, "mppi_design")) {
    X <- design$X; evn <- design$names$event; idx <- design$psych_idx
  } else {
    X <- design; evn <- event_colnames
    if (is.null(evn)) stop("Provide event_colnames when 'design' is not an mppi_design.")
    start <- ncol(X) - length(evn) + 1L; idx <- start:(start + length(evn) - 1L)
  }
  cond <- gsub("^.*hrf[A-Za-z0-9_]*\\(([^)]+)\\).*$", "\\1", evn, perl = TRUE)
  split(idx, cond)
}
