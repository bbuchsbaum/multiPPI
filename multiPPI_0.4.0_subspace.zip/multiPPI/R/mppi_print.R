#' @export
print.mppi_fit <- function(x, ...) {
  K <- length(x$names); cat(sprintf("mppi_fit: K=%d, scale=%s\n", K, x$scale))
  energies <- if (!is.null(x$basis)) vapply(x$M, function(M) sum(M^2, na.rm = TRUE), 0.0)
              else vapply(x$Delta, function(D) sum(D^2, na.rm = TRUE), 0.0)
  names(energies) <- x$names
  cat("  Frobenius energy per regressor:\n"); print(round(energies, 4))
  invisible(x)
}
#' @export
summary.mppi_fit <- function(object, ...) {
  K <- length(object$names)
  energies <- if (!is.null(object$basis)) vapply(object$M, function(M) sum(M^2, na.rm = TRUE), 0.0)
              else vapply(object$Delta, function(D) sum(D^2, na.rm = TRUE), 0.0)
  list(K = K, scale = object$scale, energies = energies, names = object$names,
       basis = if (!is.null(object$basis)) object$basis$name else NULL)
}
#' @export
print.mppi_design <- function(x, ...) {
  X <- x$X; K <- length(x$psych_idx)
  cat(sprintf("mppi_design: T=%d, q=%d, psych_cols=%d\n", nrow(X), ncol(X), K))
  if (!is.null(x$names$event)) {
    cat("  First event columns: ",
        paste(head(x$names$event, min(5L, length(x$names$event))), collapse = ", "),
        if (length(x$names$event) > 5L) " ..." else "", "\n", sep = "")
  }
  invisible(x)
}
