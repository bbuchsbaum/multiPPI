# Weighted crossproduct in chunks to lower memory footprint.
.mppi_wcp_chunked <- function(R, w, chunk_size = 2048L) {
  stopifnot(is.matrix(R), is.numeric(w), nrow(R) == length(w))
  Tn <- nrow(R); V <- ncol(R)
  D <- matrix(0, V, V)
  i <- 1L
  while (i <= Tn) {
    j <- min(Tn, i + as.integer(chunk_size) - 1L)
    Rb <- R[i:j, , drop = FALSE]
    wb <- w[i:j]
    D <- D + crossprod(Rb, wb * Rb)
    i <- j + 1L
  }
  D
}
# Chunked projection: Z = R %*% V computed in column blocks of R
.mppi_RV_chunked <- function(R, V, chunk_cols = 4096L) {
  stopifnot(is.matrix(R), is.matrix(V), ncol(R) == nrow(V))
  Tn <- nrow(R); r <- ncol(V)
  Z <- matrix(0, Tn, r)
  i <- 1L
  while (i <= ncol(R)) {
    j <- min(ncol(R), i + as.integer(chunk_cols) - 1L)
    Z <- Z + R[, i:j, drop = FALSE] %*% V[i:j, , drop = FALSE]
    i <- j + 1L
  }
  Z
}
