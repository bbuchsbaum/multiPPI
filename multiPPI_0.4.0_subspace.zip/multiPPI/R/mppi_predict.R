# Reconstruction helpers ---------------------------------------------------

#' Predict a single ROI-ROI edge from a basis-fit
#' @export
mppi_edge <- function(fit, k, i, j) {
  stopifnot(inherits(fit, "mppi_fit"), !is.null(fit$basis))
  V <- fit$basis$V; M <- fit$M[[k]]
  as.numeric(V[i, , drop = FALSE] %*% M %*% V[j, , drop = FALSE])
}

#' Predict a small Δ submatrix for selected ROIs from a basis-fit
#' @export
mppi_predict_delta <- function(fit, k, idx) {
  stopifnot(inherits(fit, "mppi_fit"), !is.null(fit$basis))
  V <- fit$basis$V[idx, , drop = FALSE]; M <- fit$M[[k]]
  D <- V %*% M %*% t(V); diag(D) <- 0; D
}
