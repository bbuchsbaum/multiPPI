# Plotting ---------------------------------------------------------------

#' Plot a fitted multiPPI object
#' @export
plot.mppi_fit <- function(x, which = c("energy","matrix","mode","degree"),
                          k = 1L, topn = 20L, zlim = NULL, main = NULL,
                          space = c("auto","basis","roi"), idx = NULL, ...) {
  which <- match.arg(which); space <- match.arg(space)
  stopifnot(inherits(x, "mppi_fit"))
  K <- length(x$names); if (K == 0) stop("No Δ/M matrices available.")
  if (k < 1 || k > K) stop(sprintf("k must be in 1..%d", K))
  if (which == "energy") {
    en <- if (!is.null(x$basis)) vapply(x$M, function(M) sum(M^2, na.rm = TRUE), 0.0)
          else vapply(x$Delta, function(M) sum(M^2, na.rm = TRUE), 0.0)
    names(en) <- x$names
    barplot(en, las = 2, ylab = "Energy (Frobenius)", main = main %||% "Δ energy by regressor", ...)
  } else if (which == "matrix") {
    if (!is.null(x$basis) && (space == "auto" || space == "basis")) {
      M <- x$M[[k]]
      if (is.null(zlim)) { m <- max(abs(M), na.rm = TRUE); zlim <- c(-m, m) }
      image(t(apply(M, 2, rev)), axes = FALSE, col = colorRampPalette(c("blue","white","red"))(200),
            zlim = zlim, main = main %||% sprintf("M (basis) k=%s", x$names[k]), ...)
      axis(1); axis(2)
    } else {
      if (!is.null(x$basis)) {
        if (is.null(idx)) stop("Provide 'idx' (ROI indices) for ROI-space display when fit was computed in a basis.")
        D <- mppi_predict_delta(x, k, idx)
      } else {
        D <- x$Delta[[k]]
        if (!is.null(idx)) D <- D[idx, idx, drop = FALSE]
      }
      if (is.null(zlim)) { m <- max(abs(D), na.rm = TRUE); zlim <- c(-m, m) }
      image(t(apply(D, 2, rev)), axes = FALSE, col = colorRampPalette(c("blue","white","red"))(200),
            zlim = zlim, main = main %||% sprintf("Δ (ROI) k=%s", x$names[k]), ...)
      axis(1); axis(2)
    }
  } else if (which == "mode") {
    if (!is.null(x$basis) && (space == "auto" || space == "basis")) {
      M <- x$M[[k]]; ev <- eigen((M + t(M))/2, symmetric = TRUE)
      v  <- ev$vectors[,1]; ord <- order(abs(v), decreasing = TRUE); sel <- ord[1:min(topn, length(v))]
      barplot(v[sel], names.arg = paste0("c", sel), las = 2,
              main = main %||% sprintf("Top-%d basis loadings of mode 1 (%s)", length(sel), x$names[k]),
              ylab = "Eigenvector weight", ...)
    } else {
      stop("Use space='basis' for mode plots when fit used a basis, or fit without basis.")
    }
  } else if (which == "degree") {
    if (!is.null(x$basis)) {
      M <- x$M[[k]]; deg <- rowSums(abs(M), na.rm = TRUE)
      ord <- order(deg, decreasing = TRUE); sel <- ord[1:min(topn, length(deg))]
      barplot(deg[sel], names.arg = paste0("c", sel), las = 2,
              main = main %||% sprintf("Top-%d components by |M| degree (%s)", length(sel), x$names[k]),
              ylab = "∑|M_{i·}|", ...)
    } else {
      D <- x$Delta[[k]]; deg <- rowSums(abs(D), na.rm = TRUE)
      ord <- order(deg, decreasing = TRUE); sel <- ord[1:min(topn, length(deg))]
      barplot(deg[sel], names.arg = if (is.null(colnames(x$R))) sel else colnames(x$R)[sel], las = 2,
              main = main %||% sprintf("Top-%d nodes by |Δ| degree (%s)", length(sel), x$names[k]),
              ylab = "∑|Δ_{i·}|", ...)
    }
  }
  invisible(x)
}
