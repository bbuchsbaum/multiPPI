mppi_group_ebayes <- function(Delta_list, use_limma = TRUE) {
  stopifnot(is.list(Delta_list), length(Delta_list) >= 2)
  V <- nrow(Delta_list[[1]])
  U <- upper.tri(matrix(0, V, V), diag = FALSE)
  X <- do.call(rbind, lapply(Delta_list, function(D) as.numeric(D[U])))
  if (use_limma && requireNamespace("limma", quietly = TRUE)) {
    design <- cbind(Intercept = 1)
    fit <- limma::lmFit(t(X), design); fit <- limma::eBayes(fit)
    tstat <- fit$t[,1]; pval <- fit$p.value[,1]
  } else {
    m <- colMeans(X); s <- apply(X, 2, sd); n <- nrow(X)
    tstat <- m / (s / sqrt(n)); pval <- 2*pt(-abs(tstat), df = n-1)
  }
  list(t = tstat, p = pval, idx_upper = which(U, arr.ind = FALSE), V = V)
}
