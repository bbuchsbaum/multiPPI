mppi_bandpass <- function(x, low = NULL, high = 0.1, order = 2L) {
  stopifnot(is.matrix(x))
  if (!is.null(low) || !is.null(high)) {
    if (requireNamespace("signal", quietly = TRUE)) {
      Wc <- c(ifelse(is.null(low), 0, low), ifelse(is.null(high), 0.499, high))
      bf <- if (is.null(low)) signal::butter(order, Wc[2], "low") else if (is.null(high)) signal::butter(order, Wc[1], "high") else signal::butter(order, Wc, "pass")
      y <- apply(x, 2, function(col) as.numeric(signal::filtfilt(bf, col))); return(matrix(y, nrow = nrow(x), ncol = ncol(x)))
    } else {
      if (!is.null(high)) { k <- max(3L, round(1/(2*high))); w <- rep(1/k, k); y <- apply(x, 2, function(col) stats::filter(col, w, sides = 2, circular = FALSE)); y[is.na(y)] <- 0; return(as.matrix(y)) }
    }
  } ; x
}
mppi_fit_multi_band <- function(Y, X, psych_idx, bands, zero_diag = TRUE, scale = c("cov","corr"),
                                backend = c("blas","chunked"), chunk_size = 2048L) {
  res <- list(); for (bd in bands) { Yb <- mppi_bandpass(Y, low = bd$low, high = bd$high); fit <- mppi.matrix(Yb, X, psych_idx, zero_diag = zero_diag, scale = match.arg(scale), backend = match.arg(backend), chunk_size = chunk_size); res[[bd$name]] <- fit } ; res
}
