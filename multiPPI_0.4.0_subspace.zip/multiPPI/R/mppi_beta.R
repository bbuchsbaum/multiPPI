mppi_coerce_beta <- function(obj) {
  if (is.matrix(obj)) return(obj)
  if (is.data.frame(obj)) { req <- c("trial","roi","beta"); if (!all(req %in% names(obj))) stop("need trial, roi, beta"); tab <- xtabs(beta ~ trial + roi, data = obj); B <- as.matrix(tab); rn <- suppressWarnings(as.integer(rownames(B))); if (all(!is.na(rn))) B <- B[order(rn), , drop = FALSE]; return(B) }
  if (is.list(obj) && all(vapply(obj, is.numeric, TRUE))) { lens <- vapply(obj, length, 1L); if (length(unique(lens)) != 1L) stop("all vecs must same length"); return(do.call(rbind, obj)) }
  stop("can't coerce to trial x V matrix")
}
mppi_fit_beta <- function(B, Pbeta, Cbeta = NULL, zero_diag = TRUE, scale = c("cov","corr")) {
  scale <- match.arg(scale); stopifnot(is.matrix(B), is.matrix(Pbeta), nrow(B) == nrow(Pbeta))
  Zb <- if (is.null(Cbeta)) cbind(1, Pbeta) else cbind(1, Cbeta, Pbeta); RB <- B - Zb %*% qr.solve(Zb, B)
  if (scale == "corr") { s <- if (requireNamespace("matrixStats", quietly=TRUE)) matrixStats::colSds(RB) else apply(RB, 2, sd); s[s == 0] <- 1; RB <- sweep(RB, 2, s, "/") }
  K <- ncol(Pbeta); out <- vector("list", K); pNms <- colnames(Pbeta); if (is.null(pNms)) pNms <- paste0("psych", seq_len(K))
  for (ii in seq_len(K)) { Qb <- if (is.null(Cbeta)) cbind(1, Pbeta[, -ii, drop = FALSE]) else cbind(1, Cbeta, Pbeta[, -ii, drop = FALSE]); pk <- Pbeta[, ii] - Qb %*% qr.coef(qr(Qb), Pbeta[, ii]); denom <- sum(pk^2)
    Dk <- if (denom < .Machine$double.eps) matrix(NA_real_, ncol(B), ncol(B)) else crossprod(RB, pk * RB) / denom; if (zero_diag) diag(Dk) <- 0; out[[ii]] <- Dk }
  names(out) <- pNms; list(Delta = out, names = pNms, RB = RB)
}
mppi_beta_permute <- function(B, Pbeta, Cbeta = NULL, run_trial = NULL, blksize = NULL, Bperm = 999L, zero_diag = TRUE) {
  fit <- mppi_fit_beta(B, Pbeta, Cbeta, zero_diag = zero_diag, scale = "cov"); res <- list()
  for (nm in fit$names) {
    pk0 <- Pbeta[, nm]; if (!is.null(run_trial)) idx <- split(seq_along(pk0), run_trial)
    else if (!is.null(blksize)) idx <- split(seq_along(pk0), ceiling(seq_along(pk0)/blksize))
    else idx <- list(seq_along(pk0))
    D0 <- fit$Delta[[nm]]; Q0 <- sum(D0^2, na.rm = TRUE); Qb <- numeric(Bperm)
    for (b in seq_len(Bperm)) {
      pkb <- pk0; if (all(pk0 %in% c(0,1))) { for (g in idx) pkb[g] <- sample(pkb[g]) }
      else { sgn <- sample(c(-1,1), length(idx), TRUE); ii <- 1L; for (g in idx) { pkb[g] <- sgn[ii]*pkb[g]; ii <- ii + 1L } }
      Pb <- cbind(pkb, Pbeta[, setdiff(colnames(Pbeta), nm), drop = FALSE]); Db <- mppi_fit_beta(B, Pb, Cbeta, zero_diag = zero_diag, scale = "cov")$Delta[[1]]; Qb[b] <- sum(Db^2, na.rm = TRUE)
    }
    p_global <- (1 + sum(Qb >= Q0)) / (Bperm + 1); res[[nm]] <- list(D = D0, Q = Q0, Qnull = Qb, p_global = p_global)
  } ; res
}
