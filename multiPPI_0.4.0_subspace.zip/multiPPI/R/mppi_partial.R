mppi_to_partial <- function(Sigma0, DeltaSigma, lambda = 1e-3) {
  V <- nrow(Sigma0); I <- diag(V); Theta0 <- solve(Sigma0 + lambda * I); - Theta0 %*% DeltaSigma %*% Theta0
}
mppi_delta_partial <- function(Theta0, DeltaTheta) { d <- 1/sqrt(diag(Theta0)); S <- d %o% d; - DeltaTheta * S }
