mppi_omnibus <- function(fit, blksize = 10L, B = 999L, wild = c("none","rademacher","mammen"), seed = NULL) {
  wild <- match.arg(wild); out <- vector("list", length(fit$names)); names(out) <- fit$names
  if (!is.null(seed)) { old <- .Random.seed; on.exit({ if (exists("old")) .Random.seed <<- old }, add = TRUE); set.seed(seed) }
  Tn <- if (!is.null(fit$Z)) nrow(fit$Z) else nrow(fit$R)
  idx <- split(seq_len(Tn), ceiling(seq_len(Tn)/blksize))
  gen_weights <- function() if (wild == "none") rep(1,length(idx)) else if (wild=="rademacher") sample(c(-1,1),length(idx),TRUE) else { p <- (sqrt(5)+1)/(2*sqrt(5)); a <- (1 - sqrt(5))/2; b <- (1 + sqrt(5))/2; sample(c(a,b), length(idx), TRUE, prob = c(1-p,p)) }
  use_basis <- !is.null(fit$basis)
  for (i in seq_along(fit$names)) {
    pk0 <- fit$pk[[i]]; denom0 <- sum(pk0^2)
    if (use_basis) {
      Z <- fit$Z
      M0 <- crossprod(Z, pk0 * Z) / denom0; diag(M0) <- 0
      Q0 <- sum(M0^2, na.rm = TRUE)
      Qb <- numeric(B)
      for (b in seq_len(B)) {
        w <- gen_weights(); pkb <- numeric(Tn); jj <- 1L; for (g in idx) { pkb[g] <- w[jj]*pk0[g]; jj <- jj + 1L }
        Mb <- crossprod(Z, pkb * Z) / sum(pkb^2); diag(Mb) <- 0
        Qb[b] <- sum(Mb^2, na.rm = TRUE)
      }
      out[[i]] <- list(M = M0, Q = Q0, Qnull = Qb, p_global = (1 + sum(Qb >= Q0)) / (B + 1))
    } else {
      D0 <- .mppi_wcp(fit$R, pk0) / denom0; diag(D0) <- 0
      Q0 <- sum(D0^2, na.rm = TRUE); Qb <- numeric(B)
      for (b in seq_len(B)) { w <- gen_weights(); pkb <- numeric(Tn); jj <- 1L; for (g in idx) { pkb[g] <- w[jj]*pk0[g]; jj <- jj + 1L }
        Db <- .mppi_wcp(fit$R, pkb) / sum(pkb^2); Qb[b] <- sum(Db^2, na.rm = TRUE) }
      out[[i]] <- list(D = D0, Q = Q0, Qnull = Qb, p_global = (1 + sum(Qb >= Q0)) / (B + 1))
    }
  } ; out
}
mppi_permute <- function(fit, k = 1L, blksize = 10L, B = 999L,
                         wild = c("none","rademacher","mammen"), studentize = TRUE, seed = NULL) {
  wild <- match.arg(wild)
  if (!is.null(seed)) { old <- .Random.seed; on.exit({ if (exists("old")) .Random.seed <<- old }, add = TRUE); set.seed(seed) }
  use_basis <- !is.null(fit$basis)
  Tn <- if (!is.null(fit$Z)) nrow(fit$Z) else nrow(fit$R)
  idx <- split(seq_len(Tn), ceiling(seq_len(Tn)/blksize))
  gen_weights <- function() if (wild == "none") rep(1,length(idx)) else if (wild=="rademacher") sample(c(-1,1),length(idx),TRUE) else { p <- (sqrt(5)+1)/(2*sqrt(5)); a <- (1 - sqrt(5))/2; b <- (1 + sqrt(5))/2; sample(c(a,b), length(idx), TRUE, prob = c(1-p,p)) }
  pk0 <- fit$pk[[k]]; denom0 <- sum(pk0^2)
  if (use_basis) {
    Z <- fit$Z; V <- ncol(Z)
    M0 <- crossprod(Z, pk0 * Z) / denom0; diag(M0) <- 0
    if (studentize) {
      S <- crossprod(Z, pk0^2 * Z) / denom0; S[S <= 0] <- min(S[S > 0], na.rm = TRUE); Z0 <- M0 / sqrt(S)
    } else Z0 <- M0
    Zb <- array(0, dim = c(V,V,B))
    for (b in seq_len(B)) {
      w <- gen_weights(); pkb <- numeric(Tn); jj <- 1L; for (g in idx) { pkb[g] <- w[jj]*pk0[g]; jj <- jj + 1L }
      Mb <- crossprod(Z, pkb * Z) / sum(pkb^2); diag(Mb) <- 0
      if (studentize) { Sb <- crossprod(Z, pkb^2 * Z) / sum(pkb^2); Sb[Sb <= 0] <- min(Sb[Sb > 0], na.rm = TRUE); Zb[,,b] <- Mb / sqrt(Sb) }
      else Zb[,,b] <- Mb
    }
    pmat <- matrix(NA_real_, V, V)
    for (i in seq_len(V)) for (j in seq_len(V)) {
      if (i == j) { pmat[i,j] <- NA_real_; next }
      z0 <- Z0[i,j]; zb <- Zb[i,j,]; pmat[i,j] <- (1 + sum(abs(zb) >= abs(z0))) / (B + 1)
    } ; return(pmat)
  } else {
    Tn <- nrow(fit$R); idx <- split(seq_len(Tn), ceiling(seq_len(Tn)/blksize))
    gen_weights <- function() if (wild == "none") rep(1,length(idx)) else if (wild=="rademacher") sample(c(-1,1),length(idx),TRUE) else { p <- (sqrt(5)+1)/(2*sqrt(5)); a <- (1 - sqrt(5))/2; b <- (1 + sqrt(5))/2; sample(c(a,b), length(idx), TRUE, prob = c(1-p,p)) }
    pk0 <- fit$pk[[k]]; denom0 <- sum(pk0^2); D0 <- .mppi_wcp(fit$R, pk0) / denom0; diag(D0) <- 0; V <- ncol(D0)
    if (studentize) { S <- .mppi_wcp(fit$R, pk0^2) / denom0; S[S <= 0] <- min(S[S > 0], na.rm = TRUE); Z0 <- D0 / sqrt(S) } else Z0 <- D0
    Zb <- array(0, dim = c(V,V,B))
    for (b in seq_len(B)) { w <- gen_weights(); pkb <- numeric(Tn); jj <- 1L; for (g in idx) { pkb[g] <- w[jj]*pk0[g]; jj <- jj + 1L }
      Db <- .mppi_wcp(fit$R, pkb) / sum(pkb^2); diag(Db) <- 0
      if (studentize) { Sb <- .mppi_wcp(fit$R, pkb^2) / sum(pkb^2); Sb[Sb <= 0] <- min(Sb[Sb > 0], na.rm = TRUE); Zb[,,b] <- Db / sqrt(Sb) }
      else Zb[,,b] <- Db }
    pmat <- matrix(NA_real_, V, V)
    for (i in seq_len(V)) for (j in seq_len(V)) {
      if (i == j) { pmat[i,j] <- NA_real_; next }
      z0 <- Z0[i,j]; zb <- Zb[i,j,]; pmat[i,j] <- (1 + sum(abs(zb) >= abs(z0))) / (B + 1)
    } ; return(pmat)
  }
}
