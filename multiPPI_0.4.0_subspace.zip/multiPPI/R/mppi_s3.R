#' Fit Matrix-PPI with natural S3 dispatch
#' @export
mppi <- function(x, ...) UseMethod("mppi")

# Matrix method: x = Y
#' @export
mppi.matrix <- function(x, X, psych_idx, scale = c("cov","corr"), zero_diag = TRUE,
                       backend = c("blas","chunked"), chunk_size = 2048L,
                       basis = NULL, project_backend = c("blas","chunked"), project_chunk_cols = 4096L, ...) {
  scale <- match.arg(scale); backend <- match.arg(backend); project_backend <- match.arg(project_backend)
  X <- .mppi_with_intercept(X); stopifnot(nrow(x) == nrow(X))
  all_idx <- seq_len(ncol(X)); p_idx <- sort(unique(psych_idx)); base_idx <- setdiff(all_idx, p_idx)
  R <- .mppi_residualize(x, X)
  if (scale == "corr") {
    s <- if (requireNamespace("matrixStats", quietly=TRUE)) matrixStats::colSds(R) else apply(R, 2, sd)
    s[s == 0] <- 1; R <- sweep(R, 2, s, "/")
  }
  # Basis branch
  if (!is.null(basis)) {
    if (!inherits(basis, "mppi_basis")) {
      if (is.list(basis) && !is.null(basis$V)) basis <- as_mppi_basis(basis$V) else basis <- as_mppi_basis(basis)
    }
    Vb <- basis$V
    Z  <- if (project_backend == "blas") R %*% Vb else .mppi_RV_chunked(R, Vb, chunk_cols = project_chunk_cols)
    outM <- vector("list", length(p_idx)); pks <- vector("list", length(p_idx)); pNms <- colnames(X)[p_idx]
    for (ii in seq_along(p_idx)) {
      k  <- p_idx[ii]; Q  <- X[, c(base_idx, setdiff(p_idx, k)), drop = FALSE]
      pk <- .mppi_residualize_vec(X[, k], Q); denom <- sum(pk^2)
      if (denom < .Machine$double.eps) { warning(sprintf("Near-zero energy in '%s'", pNms[ii])); Mk <- matrix(NA_real_, ncol(Vb), ncol(Vb)) }
      else { Mk <- crossprod(Z, pk * Z) / denom; diag(Mk) <- 0 }
      outM[[ii]] <- Mk; pks[[ii]] <- pk
    }
    names(outM) <- pNms
    return(structure(list(M = outM, names = pNms, Z = Z, pk = pks, basis = basis, scale = scale),
                    class = c("mppi_fit", "mppi_fit_basis")))
  }
  # ROI-space
  out <- vector("list", length(p_idx)); pks <- vector("list", length(p_idx)); pNms <- colnames(X)[p_idx]
  for (ii in seq_along(p_idx)) {
    k  <- p_idx[ii]; Q  <- X[, c(base_idx, setdiff(p_idx, k)), drop = FALSE]
    pk <- .mppi_residualize_vec(X[, k], Q); denom <- sum(pk^2)
    if (denom < .Machine$double.eps) { warning(sprintf("Near-zero energy in '%s'", pNms[ii])); Dk <- matrix(NA_real_, ncol(x), ncol(x)) }
    else {
      Dk <- if (backend == "blas") .mppi_wcp(R, pk) / denom else .mppi_wcp_chunked(R, pk, chunk_size) / denom
      diag(Dk) <- 0
    }
    out[[ii]] <- Dk; pks[[ii]] <- pk
  }
  names(out) <- pNms
  structure(list(Delta = out, names = pNms, R = R, pk = pks, scale = scale),
            class = "mppi_fit")
}

# Design method: x = mppi_design
#' @export
mppi.mppi_design <- function(x, Y, runs = NULL, prewhiten = TRUE, scale = c("cov","corr"), zero_diag = TRUE,
                               backend = c("blas","chunked"), chunk_size = 2048L,
                               basis = NULL, project_backend = c("blas","chunked"), project_chunk_cols = 4096L, ...) {
  D <- x; scale <- match.arg(scale); backend <- match.arg(backend); project_backend <- match.arg(project_backend)
  if (prewhiten) {
    if (!requireNamespace("fmriAR", quietly=TRUE)) {
      warning("fmriAR not available; proceeding without prewhitening.")
      return(mppi.matrix(Y, X = D$X, psych_idx = D$psych_idx, scale = scale, zero_diag = zero_diag,
                         backend = backend, chunk_size = chunk_size, basis = basis,
                         project_backend = project_backend, project_chunk_cols = project_chunk_cols))
    }
    if (is.null(runs)) stop("Provide 'runs' for prewhitening.")
    res  <- Y - D$X %*% qr.coef(qr(D$X), Y)
    plan <- fmriAR::fit_noise(res, runs = runs, method = "ar", p = "auto")
    xyw  <- fmriAR::whiten_apply(plan, X = D$X, Y = Y, runs = runs)
    return(mppi.matrix(xyw$Y, X = xyw$X, psych_idx = D$psych_idx, scale = scale, zero_diag = zero_diag,
                       backend = backend, chunk_size = chunk_size, basis = basis,
                       project_backend = project_backend, project_chunk_cols = project_chunk_cols))
  } else {
    return(mppi.matrix(Y, X = D$X, psych_idx = D$psych_idx, scale = scale, zero_diag = zero_diag,
                       backend = backend, chunk_size = chunk_size, basis = basis,
                       project_backend = project_backend, project_chunk_cols = project_chunk_cols))
  }
}

# Event-model method: x = fmridesign::event_model
#' @export
mppi.event_model <- function(x, Y, base = NULL, runs = NULL, confounds = NULL, prewhiten = TRUE,
                             scale = c("cov","corr"), zero_diag = TRUE,
                             backend = c("blas","chunked"), chunk_size = 2048L,
                             basis = NULL, project_backend = c("blas","chunked"), project_chunk_cols = 4096L, ...) {
  D <- as_mppi_design(event = x, baseline = base, confounds = confounds, include_intercept = TRUE)
  mppi.mppi_design(D, Y = Y, runs = runs, prewhiten = prewhiten, scale = match.arg(scale), zero_diag = zero_diag,
                   backend = match.arg(backend), chunk_size = chunk_size,
                   basis = basis, project_backend = match.arg(project_backend), project_chunk_cols = project_chunk_cols, ...)
}
