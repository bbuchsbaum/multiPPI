mppi_rank_cv <- function(R, pk, Delta, holdout_frac = 0.2, R_reps = 3) {
  Tn <- nrow(R); V <- ncol(R); rmax <- min(50L, V); ranks <- 0:rmax
  losses <- matrix(0, nrow = R_reps, ncol = length(ranks))
  for (rep in seq_len(R_reps)) {
    H <- sort(sample.int(Tn, floor(holdout_frac*Tn))); K <- setdiff(seq_len(Tn), H)
    denomK <- sum(pk[K]^2); denomH <- sum(pk[H]^2)
    DeltaK <- if (denomK < .Machine$double.eps) matrix(0, V, V) else crossprod(R[K,], pk[K]*R[K,]) / denomK
    targetH <- if (denomH < .Machine$double.eps) matrix(0, V, V) else crossprod(R[H,], pk[H]*R[H]) / denomH
    sK <- svd(DeltaK, nu = min(rmax, V), nv = min(rmax, V))
    for (j in seq_along(ranks)) { r <- ranks[j]; approx <- if (r == 0) matrix(0, V, V) else sK$u[,1:r,drop=FALSE] %*% diag(sK$d[1:r]) %*% t(sK$u[,1:r,drop=FALSE]); losses[rep, j] <- mean((targetH - approx)^2, na.rm = TRUE) }
  }; rstar <- ranks[ which.min(colMeans(losses)) ]; list(r = rstar, losses = as.numeric(colMeans(losses)), ranks = ranks)
}
