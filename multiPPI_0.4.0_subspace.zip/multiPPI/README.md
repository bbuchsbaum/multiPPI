# multiPPI 0.4.0 — Subspace (basis) multiPPI

## Natural S3 interface
- `mppi(ev, Y, base=..., runs=..., prewhiten=TRUE, scale="corr", basis=as_mppi_basis(V))`
- `mppi(as_mppi_design(event=ev, baseline=base), Y, runs=..., basis=..., project_backend="chunked")`
- `mppi(Y, X, psych_idx, basis=NULL)`

## Basis workflow
- Orthornormal basis `V` (voxels/ROIs × r).
- Project: `Z = R %*% V`.
- Compute: `M_k = Z' diag(pk) Z / ||pk||^2` (diag zeroed).
- Group-level: test energies and edges in `M_k` (size r×r).
- Reconstruct edges/submatrices on demand: `mppi_edge()`, `mppi_predict_delta()`.

## Inference
- `mppi_omnibus()`, `mppi_permute()` branch automatically to basis when available.
- `seed=` for reproducibility; block sign-flips within run recommended.
